
-- Program name: BookStoreDB.sql                                        
--                                                                     
-- Description:  Setup file for user DB2 database for the BookStore    
--               Scenario for the WebSphere Message Broker Basics Redbook.                                              
--                                                                    
-- Statement:                     
--              (c) Copyright IBM Corp. 2005;                              
--              All Rights Reserved;                                            
--              US Government Users Restricted Rights - use,                    
--              duplication or disclosure restricted by GSA                     
--              ADP Schedule Contract with IBM Corp.;                           
-- Function:                                                          
-- This file creates a database called BSTOREDB for use by the      
-- Scenario for the WebSphere Message Broker Basics Redbook, 
-- connects and binds to the database, creates an   
-- ODBC connection to the database, creates tables called CUSTACCTB, BOOKCTLGTB, 
-- BOOKORDRTB and puts some sample data into the BOOKCTLGTB table.                                 
--                                                                  
-- This file connects to the database with the userID which is            
-- currently logged-on.  As a result, the schema for the tables     
-- will be userid.BOOKCTLGTB and userid.BOOKORDRTB.  It also         
-- assumes the default DB2 instance (DB2).                          
--                                                                   
-- To run this file, ensure that DB2 is started (db2start).        
-- From a DB2 command window, issue db2 -vf BookStoreDB.sql, where   
-- BookStoreDB.sql is the fully-qualified path to this file.         
-- 
--
CREATE DB BSTOREDB
CONNECT TO BSTOREDB
BIND '%DB2TEMPDIR%\bnd\@db2cli.lst' blocking all grant public
CATALOG SYSTEM ODBC DATA SOURCE BSTOREDB
CONNECT RESET
CONNECT TO BSTOREDB
DROP TABLE BOOKORDRTB
CREATE TABLE BOOKORDRTB (USERID CHAR(15) NOT NULL, ORDERNO VARCHAR(40) NOT NULL,  TIMESTAMP CHAR(25) NOT NULL, ISBN CHAR(10) NOT NULL, BOOK_PRICE FLOAT NOT NULL)
DROP TABLE CUSTACCTB
CREATE TABLE CUSTACCTB (LAST_NAME CHAR(20) NOT NULL, FIRST_NAME CHAR(20) NOT NULL, USERID CHAR(15) NOT NULL, PASSWORD CHAR(15) NOT NULL, EMAIL CHAR(25), DAY_PHONE CHAR(15), EVE_PHONE CHAR(15), SHIP_ADDRESS1 CHAR(20), SHIP_ADDRESS2 CHAR(20), SHIP_TOWN CHAR(20), SHIP_POSTCODE CHAR(20), BILL_ADDRESS1 CHAR(20), BILL_ADDRESS2 CHAR(20), BILL_TOWN CHAR(20), BILL_POSTCODE CHAR(20), CARDTYPE CHAR(20), CARDNUM CHAR(30), EXP_DATE DATE, ISS_DATE DATE, ISS_NUM INTEGER, SECCODE INTEGER)
CONNECT RESET
TERMINATE


