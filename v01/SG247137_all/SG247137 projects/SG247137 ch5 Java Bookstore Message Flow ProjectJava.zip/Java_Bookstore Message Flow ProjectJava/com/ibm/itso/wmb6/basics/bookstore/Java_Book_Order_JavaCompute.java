/*
 * Created on 8/10/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ibm.itso.wmb6.basics.bookstore;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbMessage;
import com.ibm.broker.plugin.MbMessageAssembly;
import com.ibm.broker.plugin.MbRecoverableException;
import com.ibm.broker.plugin.MbXML;

/**
 * WebSphere Message Broker Basics Redbook
 * 
 * Application Development Chapter, Create Book Order Java Compute Node Example
 *  
 * @see com.ibm.broker.javacompute.MbJavaComputeNode
 */
public class Java_Book_Order_JavaCompute extends MbJavaComputeNode {
    /** Delivery Indicator - Yes - Constant */
    private static final String DI_YES = "Yes";

    /** Delivery Method - First Class - Constant */
    private static final String DM_1ST_CLASS = "First_Class";

    /** Delivery Method - First Class - Price Constant */
    private static final BigDecimal DM_1ST_CLASS_PRICE = new BigDecimal("18.00");

    /** Delivery Method - Second Class - Constant */
    private static final String DM_2ND_CLASS = "Second_Class";

    /** Delivery Method - Second Class - Price Constant */
    private static final BigDecimal DM_2ND_CLASS_PRICE = new BigDecimal("12.00");
    
    /** Delivery Method - Airmail - Constant */
    private static final String DM_AIRMAIL = "Airmail";

    /** Delivery Method - Airmail - Price Constant */
    private static final BigDecimal DM_AIRMAIL_PRICE = new BigDecimal("8.00");

    /** Order Date Format Constant */
    private static final String ORDER_DATE_FORMAT = "yyyyMMddHHmmss";
    
    /** Order Status Message Constant */
    private static final String ORDER_STATUS_MSG = "Order Received";
    
	/**
	 * Copies Message Headers from Input Message to Output Message
	 * 
	 * @param inMessage the input message
	 * @param outMessage the output message
	 * @throws MbException
	 */
	private void copyMessageHeaders(MbMessage inMessage, MbMessage outMessage) throws MbException {
		//
		// Retrieve required elements
		//
	    MbElement inputHeaderElement = inMessage.getRootElement().getFirstChild();
		MbElement outputRootElement = outMessage.getRootElement();

		//
		// Copy input message header information to output message root element, if present
		//
		while((inputHeaderElement != null) && (inputHeaderElement.getNextSibling() != null)) {
			outputRootElement.addAsLastChild(inputHeaderElement.copy());
	        inputHeaderElement = inputHeaderElement.getNextSibling();
		}
	}

	/**
	 * Constructs the Order Number
	 * 
	 * This is a combination of the Customer_ID and Order_Date
	 * 
	 * @param pCustomerID the customer identifier
	 * @param pOrderDate the order date
	 * @return the order number
	 * @throws MbException
	 */
	private String constructOrderNumber(MbElement pCustomerID, MbElement pOrderDate) throws MbException {
	    String orderNumber = null;

	    //
	    // Extract values
	    //
	    String customerIdValue = (String) pCustomerID.getValue();
	    
	    //
	    // Format Date
	    //
	    SimpleDateFormat dateFormatter = new SimpleDateFormat(ORDER_DATE_FORMAT);
	    Date date = null;
	    
	    try {
	        date = dateFormatter.parse((String)pOrderDate.getValue());

	    } catch(ParseException pEx) {
	        throw new MbRecoverableException(
	                Java_Book_Order_JavaCompute.class.getName(),
	                "constructOrderNumber()",
	                null,
	                null,
	                "Failed to parse Order_Date to Date object",
	                null);
	    }
	    
	    String OrderDateString = dateFormatter.format(date);  

	    //
	    // Construct order number
	    //
	    orderNumber = customerIdValue + OrderDateString;
	    
	    return orderNumber;
	}
	
	/**
	 * Determines the Delivery Price based on the Delivery Method specified:
	 * 
	 * METHOD			PRICE
	 * -------------  	-------
	 * First_Class		$18.00
	 * Second_Class		$12.00
	 * Airmail			$08.00
	 * 
	 * If NULL is returned, this means an unknown delivery method was specified
	 * 
	 * @param pDeliveryMethod the delivery method selected
	 * @return the delivery price
	 * @throws MbException
	 */
	private BigDecimal determineDeliveryPrice(MbElement pDeliveryMethod) throws MbException {
	    BigDecimal deliveryPrice = null;
	    String deliveryMethod = (String) pDeliveryMethod.getName();
	    String deliveryIndicator = (String) pDeliveryMethod.getValue();
	    
	    //
	    // Calculate delivery cost only if indicator is Yes
	    //
	    if (deliveryIndicator.equals(DI_YES)) {
		    if (deliveryMethod.equals(DM_1ST_CLASS)) {
		        //
		        // Delivery is First_Class (18.00)
		        //
		        deliveryPrice = DM_1ST_CLASS_PRICE;

		    } else if (deliveryMethod.equals(DM_2ND_CLASS)) {
		        //
		        // Delivery is Second_Class (12.00)
		        //
		        deliveryPrice = DM_2ND_CLASS_PRICE;

		    } else if (deliveryMethod.equals(DM_AIRMAIL)) {
		        //
		        // Delivery is Airmail (8.00)
		        //
		        deliveryPrice = DM_AIRMAIL_PRICE;
		    }
	    }

	    return deliveryPrice;
	}

	/**
	 * Calculates Book Total Price
	 * 
	 * @param pBookPriceList the list of book prices to be totalled
	 * @return the book total price
	 * @throws MbException
	 */
	private BigDecimal calculateBookTotalPrice(List pBookPriceTotal) throws MbException {
	    MbElement priceElement = null;
	    BigDecimal bookPrice = null;
	    BigDecimal totalPrice = new BigDecimal("0.00");
	    
	    //
	    // Iterate over all prices and calculate total
	    //
	    for (int i=0, imax=pBookPriceTotal.size(); i < imax; i++) {
	        priceElement = (MbElement) pBookPriceTotal.get(i);
	        bookPrice = new BigDecimal((String)priceElement.getValue());
	        totalPrice = totalPrice.add(bookPrice);
	    }
	    
	    return totalPrice;
	}
	
	/*
	 * @see com.ibm.broker.javacompute.MbJavaComputeNode#evaluate(com.ibm.broker.plugin.MbMessageAssembly)
	 */
	public void evaluate(MbMessageAssembly inAssembly) throws MbException {
		//
		// Retrieve input message
		//
		MbMessage inMessage = inAssembly.getMessage();

		//
		// Construct empty output message
		//
		MbMessage outMessage = new MbMessage();
	    MbMessageAssembly outAssembly = new MbMessageAssembly(inAssembly, outMessage);

	    //
	    // Build output message
	    //
	    copyMessageHeaders(inMessage, outMessage);

	    MbElement inputRoot = inMessage.getRootElement();
	    MbElement inputBody = inputRoot.getLastChild();
	    MbElement outputRoot = outMessage.getRootElement();
	    MbElement outputBody = outputRoot.createElementAsLastChild(MbXML.PARSER_NAME);

	    // Root element
	    MbElement bookOrderResponseMsg = outputBody.createElementAsLastChild(MbXML.ELEMENT, "Book_Order_Response_MSG", null);

	    // Customer ID
	    MbElement inputCustomerIdElement = inputBody.getFirstElementByPath("./Create_Book_Order_MSG/Customer_ID");
	    bookOrderResponseMsg.createElementAsLastChild(MbXML.ELEMENT, inputCustomerIdElement.getName(), inputCustomerIdElement.getValue());
	    
	    // Order Number
	    MbElement inputOrderDateElement = inputBody.getFirstElementByPath("./Create_Book_Order_MSG/Order_Date");
	    String orderNumber = constructOrderNumber(inputCustomerIdElement, inputOrderDateElement);
	    bookOrderResponseMsg.createElementAsLastChild(MbXML.ELEMENT, "OrderNumber", orderNumber);

	    // Order Date
	    bookOrderResponseMsg.createElementAsLastChild(MbXML.ELEMENT, inputOrderDateElement.getName(), inputOrderDateElement.getValue());

	    // Delivery Method (First_Class/Second_Class/Airmail)
	    MbElement inputDeliveryMethodElement = inputOrderDateElement.getNextSibling();
	    
	    if (inputDeliveryMethodElement.getValue().equals(DI_YES)) {
	        bookOrderResponseMsg.createElementAsLastChild(MbXML.ELEMENT, inputDeliveryMethodElement.getName(), inputDeliveryMethodElement.getValue());
	    }

	    // Book Details
	    MbElement inputBookDetails = inputBody.getFirstElementByPath("./Create_Book_Order_MSG/Book_Details");
	    MbElement outputBookDetails = bookOrderResponseMsg.createElementAsLastChild(MbXML.ELEMENT, inputBookDetails.getName(), null);
	    outputBookDetails.copyElementTree(inputBookDetails);
	    
	    // Delivery Price
	    BigDecimal deliveryPrice = determineDeliveryPrice(inputDeliveryMethodElement);
	    
	    if (deliveryPrice != null) {
		    bookOrderResponseMsg.createElementAsLastChild(MbXML.ELEMENT, "Delivery_Price", deliveryPrice);
	    }

	    // Total Price
	    List bookPricesList = (List) inputBody.evaluateXPath("./Create_Book_Order_MSG/Book_Details/Book_Price");
	    bookOrderResponseMsg.createElementAsLastChild(MbXML.ELEMENT, "Total_Price", calculateBookTotalPrice(bookPricesList));
	    
	    // Order Status
	    bookOrderResponseMsg.createElementAsLastChild(MbXML.ELEMENT, "Order_Status", ORDER_STATUS_MSG);

	    //
	    // Propagate message
	    //
	    getOutputTerminal("out").propagate(outAssembly);

	    //
	    // Clear out message
	    //
		outMessage.clearMessage();
	}
}