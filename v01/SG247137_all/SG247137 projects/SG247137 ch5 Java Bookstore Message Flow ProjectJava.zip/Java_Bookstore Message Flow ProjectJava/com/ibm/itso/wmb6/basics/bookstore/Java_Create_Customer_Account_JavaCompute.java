/*
 * Created on 24-Oct-2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.ibm.itso.wmb6.basics.bookstore;

import com.ibm.broker.javacompute.MbJavaComputeNode;
import com.ibm.broker.plugin.*;

/**
 * @author wmbuser
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Java_Create_Customer_Account_JavaCompute extends MbJavaComputeNode {

	public void evaluate(MbMessageAssembly assembly) throws MbException {
		MbOutputTerminal out = getOutputTerminal("out");
		MbOutputTerminal alt = getOutputTerminal("alternate");

		MbMessage message = assembly.getMessage();

		// ----------------------------------------------------------
		// Add user code below
		MbMessage newMsg = new MbMessage(assembly.getMessage());
		MbMessageAssembly newAssembly = new MbMessageAssembly(assembly, newMsg);

		String table = "dbTable";

		MbSQLStatement state = createSQLStatement( 	"BSTOREDB",
		"INSERT INTO Database.CUSTACCTB(LAST_NAME, FIRST_NAME, USERID, PASSWORD, EMAIL, DAY_PHONE, EVE_PHONE, SHIP_ADDRESS1, SHIP_ADDRESS2, SHIP_TOWN, SHIP_POSTCODE, BILL_ADDRESS1, BILL_ADDRESS2, BILL_TOWN, BILL_POSTCODE, CARDTYPE, CARDNUM, EXP_DATE, ISS_DATE, ISS_NUM, SECCODE) " +
				"VALUES(InputRoot.XML.Create_Customer_Account_MSG.Personal_Details.Last_Name, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Personal_Details.First_Name, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Personal_Details.User_ID, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Personal_Details.Password, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Email_Address, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Daytime_Telephone, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Evening_Telephone, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Shipping_Address.Address_1, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Shipping_Address.Address_2, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Shipping_Address.Town, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Shipping_Address.Postcode, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Billing_Address.Address_1, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Billing_Address.Address_2, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Billing_Address.Town, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Billing_Address.Postcode, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Payment_Details.Card, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Payment_Details.Card_Number, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Payment_Details.Expiry_Date, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Payment_Details.Issue_Date, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Payment_Details.Issue_Number, " +
					"InputRoot.XML.Create_Customer_Account_MSG.Payment_Details.Security_Code);");

			state.setThrowExceptionOnDatabaseError(true);
			state.setTreatWarningsAsErrors(true);
			state.select(assembly, newAssembly);

			int sqlCode = state.getSQLCode();
			if (sqlCode != 0) {
				// Do error handling here
			}
		// End of user code
		// ----------------------------------------------------------

		// The following should only be changed
		// if not propagating message to the 'out' terminal

		out.propagate(assembly);
	}
}
