import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Calendar;
import java.text.SimpleDateFormat;


public class Receiver{

	ServerSocket sSocket;
	int port ;
	private static Receiver receiver;
	public static void main(String[] args) throws Exception {
		int port = 1111;
		if(args.length >0){
			port   = Integer.parseInt(args[0]);
		}
		
		receiver = new Receiver();
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		System.out.println("\n====> Receiver is open at " + sdf.format(cal.getTime()) + " ... now waiting for data ...");
		receiver.runReceiver(port);
	}
	
	public void runReceiver(int port) {
		try {
			this.port = port;
			sSocket = new ServerSocket(port);
			while(true){
			  Socket socket = sSocket.accept();
			  ReceiveData receiveData = new ReceiveData(socket);
			  Thread thread = new Thread(receiveData);
			  thread.start();
			  
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public class ReceiveData implements Runnable{
		BufferedInputStream bis;
		OutputStream os;
		InputStream is;
		InputStreamReader isr;
		BufferedReader br;
		Socket socket;
		public ReceiveData(Socket socket) {
		try {
			this.socket = socket;
			BufferedInputStream bis = new BufferedInputStream(socket.getInputStream());
			isr = new InputStreamReader(bis);
			br = new BufferedReader(isr);
			os = socket.getOutputStream();

		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

		public void run() {
			try {
			  while (true) {
				String line = br.readLine();
				System.out.println("====> Received data: "+line);
				System.out.println("====> About to echo the same data back again ...");
				os.write(line.getBytes());
				os.write("\n".getBytes());
				System.out.println("====> Sending data: "+line);
				Calendar cal = Calendar.getInstance();
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
				System.out.println("====> Receiver is open at " + sdf.format(cal.getTime()) + " ... now waiting for data ...");				  
			  }
		    } catch (Exception e) {
			  e.printStackTrace();
		    }
		}
	}
}
