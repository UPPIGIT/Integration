import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;


public class Sender extends Thread {

	String message;
	byte[] messageBytes ;
	
	Socket clientSocket;
	OutputStream os;
	InputStream is;
	InputStreamReader isr;
	BufferedReader br;
	int port ;
	
	public static void main(String[] args) throws Exception {
		int number= 1;
		int port  = 1111;
		if(args.length >0){
			port   = Integer.parseInt(args[0]);
		}
		if(args.length >1){
			number = Integer.parseInt(args[1]);
		}
		for (int i = 0; i < number; i++) {
			new Sender(port).start();
		}
	}
	
	public Sender(int port){
		this.port = port;
		
		
	}
	
	public void run() {
		
		try {
	      clientSocket = new Socket("localhost", port);
		  os = clientSocket.getOutputStream();
		  is = clientSocket.getInputStream();
		  isr = new InputStreamReader(is);
		  br = new BufferedReader(isr);
		  while (true) {
			  System.out.println("\n====> Please enter the data you would like to be sent:");
			  message = (new BufferedReader(new InputStreamReader(System.in))).readLine();
			  messageBytes = message.getBytes();
			  os.write(messageBytes);
			  os.write("\n".getBytes());
			  System.out.println("====> Sending Data: "+new String(messageBytes));
			  String line  = br.readLine();
			  System.out.println("====> Received Data: "+line);
			
		  }
		}
		catch (Exception e) {
		  e.printStackTrace();
		}
	}
}
